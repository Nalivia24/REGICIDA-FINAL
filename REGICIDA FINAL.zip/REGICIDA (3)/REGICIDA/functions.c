#include "header.h"
void printarTabuleiro(jogo *jogo) {
  printf("\n       0     1     2     3     4     5   \n");
  printf("    -------------------------------------\n");
  for (int k = 0; k < 6; k++) {
    printf("%d - | %s | %s | %s | %s | %s | %s |\n", k,
           jogo->tabuleiro[k][0].nome, jogo->tabuleiro[k][1].nome,
           jogo->tabuleiro[k][2].nome, jogo->tabuleiro[k][3].nome,
           jogo->tabuleiro[k][4].nome, jogo->tabuleiro[k][5].nome);
    printf("    -------------------------------------\n");
  }
}

void guerra(jogo *jogo) {
  jogo->coroas = 0;
  int contadorObjetivo = 0;
  for (int ctrlObjetivo = 0; ctrlObjetivo < 7; ctrlObjetivo++) {
    if (ctrlObjetivo == 5) {
      continue;
    }
    for (int ctrlTabuleiroX = 1; ctrlTabuleiroX < 5; ctrlTabuleiroX++) {
      for (int ctrlTabuleiroY = 1; ctrlTabuleiroY < 5; ctrlTabuleiroY++) {
        if (jogo->tabuleiro[ctrlTabuleiroX][ctrlTabuleiroY].nome[1] == jogo->objetivo[ctrlObjetivo].nome[1]) {
          contadorObjetivo++;
        }
      }
    }
    if (contadorObjetivo == ctrlObjetivo) {
      jogo->coroas++;
    }
  }
  jogo->estado++;
}

void printarObjeitivo(jogo *jogo) {
  printf("                    __%c__   \n", jogo->objetivoAux[2].nome[1]); // 2
  printf("                   /  2  \\    \n");
  printf("                 %c/3     1\\%c\n", jogo->objetivoAux[3].nome[1],jogo->objetivoAux[1].nome[1]); // 3 1
  printf("                 %c\\4     0/%c\n", jogo->objetivoAux[4].nome[1],jogo->objetivoAux[0].nome[1]); // 4 0
  printf("                   \\5___6/  \n");
  printf("                        %c   \n",jogo->objetivoAux[6].nome[1]); // 5 6
}

void intriga(jogo *jogo) {
  int xA, yA, xB, yB, ctrlIntriga, virarLado, verifica, verificaAdj=1;
  casa aux;
  for (int quantidadeIntriga = 0; quantidadeIntriga < 6; quantidadeIntriga++) {
    system("cls");
    printarObjeitivo(jogo);
    printarTabuleiro(jogo);
    tabelaPontos(jogo);
    printf("Voc� tem %d intrigas.\nContinuar com intriga?\n1-Sim 0-N�o\n",6 - quantidadeIntriga);
    scanf("%d", &ctrlIntriga);
    if (ctrlIntriga == 0) {
      break;
    }

    do {
      do {
        printf("Linha do elemento 1: ");
        scanf("%d", &xA);
        printf("\nColuna do elemento 1: ");
        scanf("%d", &yA);
        if ((xA < 0 || xA > 5) || (yA < 0 || yA > 5) || (jogo->tabuleiro[xA][yA].trava == 1)) {
          printf("\nA casa j� foi virada no tabuleiro selecione outra");
        }
      } while ((xA < 0 || xA > 5) || (yA < 0 || yA > 5) || (jogo->tabuleiro[xA][yA].trava == 1));
      do {
        printf("\nLinha do elemento 2: ");
        scanf("%d", &xB);
        printf("\nColuna do elemento 2: ");
        scanf("%d", &yB);
        if ((xB < 0 || xB > 5) || (yB < 0 || yB > 5) || (jogo->tabuleiro[xB][yB].trava == 1)) {
          printf("\nA casa j� foi virada no tabuleiro selecione outra\n");
        }

      } while ((xB < 0 || xB > 5) || (yB < 0 || yB > 5) || (jogo->tabuleiro[xB][yB].trava == 1));

      if (((buscaTrava(jogo, xA, yA == 1)) && (buscaTrava(jogo, xB, yB == 1)))) {
        printf("\nAs duas casa j� foram virados na tabela de pontos, selecione outras");
      }

    } while (((buscaTrava(jogo, xA, yA == 1)) && (buscaTrava(jogo, xB, yB == 1))) || adj(xA, yA, xB, yB)==0);
    aux = jogo->tabuleiro[xA][yA];
    jogo->tabuleiro[xA][yA] = jogo->tabuleiro[xB][yB];
    jogo->tabuleiro[xB][yB] = aux;
    do {
      verifica = 0;
      printf("Qual casa no tabuleiro voc� quer virar para o lado escuro?\n 1- %c  2- %c\n",jogo->tabuleiro[xA][yA].nome[1], jogo->tabuleiro[xB][yB].nome[1]);
      scanf("%d", &virarLado);
      if (virarLado == 1 && jogo->tabuleiro[xA][yA].trava == 0) {
        virarLadoAlfa(jogo, xA, yA);
      } else if (virarLado == 2 && jogo->tabuleiro[xB][yB].trava == 0) {
        virarLadoAlfa(jogo, xB, yB);
      } else {
        verifica = 1;
      }
      if (verifica == 1) {
        printf("\nOp��o inv�lida\n");
      }
    } while (verifica == 1);

    do {
      verifica = 0;
      printf("Qual casa na tabela de pontos voc� quer virar para o lado escuro?\n 1 - %c  2- %c\n", jogo->tabuleiro[xA][yA].nome[1], jogo->tabuleiro[xB][yB].nome[1]);
      scanf("%d", &virarLado);
      if (virarLado == 1 && buscaTrava(jogo, xA, yA) == 0) {
        virarLadoBeta(jogo, xA, yA);
      } else if (virarLado == 2 && buscaTrava(jogo, xA, yA) == 0) {
        virarLadoBeta(jogo, xB, yB);
      } else {
        verifica = 1;
      }
      if (verifica == 1) {
        printf("\nOp��o inv�lida");
      }
    } while (verifica == 1);
  }
  jogo->estado++;
}

void virarLadoAlfa(jogo *jogo, int x, int y) {
  jogo->tabuleiro[x][y].nome[0] = '{';
  jogo->tabuleiro[x][y].nome[2] = '}';
  jogo->tabuleiro[x][y].trava = 1;
}

int buscaTrava(jogo *jogo, int x, int y) {
  for (int ctrlPontoX = 0; ctrlPontoX < 2; ctrlPontoX++) {
    for (int ctrlPontoY = 0; ctrlPontoY < 3; ctrlPontoY++) {
      if (jogo->ponto[ctrlPontoX][ctrlPontoY].nome[1] == jogo->tabuleiro[x][y].nome[1]) {
        return jogo->ponto[ctrlPontoX][ctrlPontoY].trava;
      }
    }
  }
  return 0;
}
int adj(int xA,int yA,int xB,int yB){
    for(int ctrlX=-1; ctrlX<2;ctrlX++){
            for(int ctrlY=-1; ctrlY<2;ctrlY++){
                if((ctrlX==ctrlY) || (ctrlX== -ctrlY)){
                    continue;
                }else{
                    if(xA==xB+ctrlX && yA==yB+ctrlY){
                        return 1;
                    }
                }
             }
          }
    return 0;
}
void virarLadoBeta(jogo *jogo, int x, int y) {
  for (int ctrlPontoX = 0; ctrlPontoX < 2; ctrlPontoX++) {
    for (int ctrlPontoY = 0; ctrlPontoY < 3; ctrlPontoY++) {
      if (jogo->ponto[ctrlPontoX][ctrlPontoY].nome[1] == jogo->tabuleiro[x][y].nome[1]) {
        jogo->ponto[ctrlPontoX][ctrlPontoY].nome[0] = '{';
        jogo->ponto[ctrlPontoX][ctrlPontoY].nome[2] = '}';
        jogo->ponto[ctrlPontoX][ctrlPontoY].trava = 1;
      }
    }
  }
}

void preencherPilha(jogo *jogo) {
  srand(time(NULL));
  for (int ctrlCasa = 0; ctrlCasa < 6; ctrlCasa++) {
    for (int ctrlQuantidade = 0; ctrlQuantidade < 6; ctrlQuantidade++) {
      int ctrlPosicao;
      do {
        ctrlPosicao = rand() % 36;
      } while (strcmp(jogo->pilha[ctrlPosicao].nome, "   ") == 1);
      jogo->pilha[ctrlPosicao] = jogo->casas[ctrlCasa];
    }
  }
}

void corvo(jogo *jogo) {
  for (int ctrlCorvo = 0; ctrlCorvo < 7; ctrlCorvo++) {
    jogo->objetivoAux[ctrlCorvo] = jogo->objetivo[ctrlCorvo];
  }
  printarObjeitivo(jogo);
  printarTabuleiro(jogo);
  jogo->estado++;
}

void tabelaPontos(jogo *jogo) {
  printf("             -------------------\n");
  printf("             | %s | %s | %s |\n", jogo->ponto[0][0].nome,jogo->ponto[0][1].nome, jogo->ponto[0][2].nome);
  printf("             | %s | %s | %s |\n", jogo->ponto[1][0].nome,jogo->ponto[1][1].nome, jogo->ponto[1][2].nome);
  printf("             -------------------\n");
}

void novoJogo(jogo *jogo) {
  jogo->estado=0;
  srand(time(NULL));
  leituraNovoJogo(jogo);
  preencherPilha(jogo);
  for (int ctrlCasa = 0; ctrlCasa < 6; ctrlCasa++) {
    int posicaoCasa;
    do {
      posicaoCasa = rand() % 7;
    } while ((posicaoCasa == 5) || (strcmp(jogo->objetivo[posicaoCasa].nome, " # ") == 1));
    jogo->objetivo[posicaoCasa] = jogo->casas[ctrlCasa];
  }
  printf("\nEscolha a dificuldade do seu jogo\n");
  printf("1- F�cil  2- M�dio  3- Dif�cil\n");
  scanf("%d", &jogo->dificuldade);
  system("cls");
  jogar(jogo);
}

void revelacao(jogo *jogo) {
  for (int ctrlRevela = 0; ctrlRevela < (CINCO -(jogo->dificuldade)); ctrlRevela++) {
    int escolha;
    printarObjeitivo(jogo);
    do {
      printf("Informe qual a %d� casa que deseja revelar.\n", ctrlRevela + 1);
      scanf("%d", &escolha);
    } while ((escolha == 5) || (strcmp(jogo->objetivoAux[escolha].nome, " # ") == 1));
    jogo->objetivoAux[escolha] = jogo->objetivo[escolha];
    system("cls");
  }
  jogo->estado=1;
}

void expansao(jogo *jogo) {
  int x, y, verificadorAlfa=0,verificadorBeta;
  for (int expansao = 0; expansao < 36; expansao++) {
    do {
      verificadorBeta=0;
      printarObjeitivo(jogo);
      printarTabuleiro(jogo);
      tabelaPontos(jogo);
      printf("Escolha as posi��es dos elementos da pilha, com linhas e colunas numeradas de 0 a 5\n");
      printf("\nInsira informa��es v�lidas para o elemento: %s",jogo->pilha[35 - (expansao)].nome);
      printf("\nLinha para elemento: ");
      scanf("%d", &x);
      printf("Coluna para elemento: ");
      scanf("%d", &y);
      system("cls");
      if(strcmp(jogo->tabuleiro[x][y].nome,"   ")==1){
        verificadorBeta=4;
      }
      if(verificadorAlfa!=0){
          for(int ctrlX=-1; ctrlX<2;ctrlX++){
            for(int ctrlY=-1; ctrlY<2;ctrlY++){
                if((ctrlX==ctrlY) || (ctrlX== -ctrlY)){
                    continue;
                }else{
                    if((strcmp(jogo->tabuleiro[x+ctrlX][y+ctrlY].nome,"   ")==0)){
                        verificadorBeta++;
                    }else if((x+ctrlX < 0 || x+ctrlX > 5) || (y+ctrlY < 0 || y+ctrlY > 5)){
                        verificadorBeta++;
                    }
                }
             }
          }
      }

      if(verificadorBeta==4){
             printf("\nA casa n�o possui adjacentes\n");
      }
      verificadorAlfa++;
    } while ((x < 0 || x > 5) || (y < 0 || y > 5) || (verificadorBeta>=4) ); // pedindo informa��es para preencher a matriz
    jogo->tabuleiro[x][y] = jogo->pilha[35 - (expansao)];
    system("cls");
  }
  jogo->estado++;
}

void verifica(jogo *jogo) {
  if (jogo->coroas == 6) {
    printf("VIT�RIA");
  } else {
    printf("Voc� perdeu. Cumpriu %d objetivos", jogo->coroas);
  }
  jogo->estado=-1;
}

void jogar(jogo *jogo) {
    while(jogo->estado!=-1){
      switch(jogo->estado){
          case 0:
            revelacao(jogo);
            gravacao(jogo);
          case 1:
            expansao(jogo);
            gravacao(jogo);
          case 2:
            corvo(jogo);
            gravacao(jogo);
          case 3:
            intriga(jogo);
            gravacao(jogo);
          case 4:
            guerra(jogo);
            gravacao(jogo);
          case 5:
            verifica(jogo);
      }

    }
}

void gravacao(jogo *jogo) {
    FILE *pont_arq;
    char palavra[20];
    int valor;
    pont_arq = fopen("dados.csv", "w");
    if (pont_arq == NULL) {
        printf("Erro na abertura do arquivo!");
    }

    for(int i=0;i<36;i++){
        strcpy(palavra,jogo->pilha[i].nome);
        fprintf(pont_arq, "%s,", palavra);
    }


    for (int ctrlTabuleiroX = 0; ctrlTabuleiroX < 6; ctrlTabuleiroX++) {
        for (int ctrlTabuleiroY = 0; ctrlTabuleiroY < 6; ctrlTabuleiroY++) {
                strcpy(palavra,jogo->tabuleiro[ctrlTabuleiroX][ctrlTabuleiroY].nome);
                fprintf(pont_arq, "%s,", palavra);
        }
    }
    for (int ctrlTabuleiroX = 0; ctrlTabuleiroX < 6; ctrlTabuleiroX++) {
        for (int ctrlTabuleiroY = 0; ctrlTabuleiroY < 6; ctrlTabuleiroY++) {
                valor = jogo->tabuleiro[ctrlTabuleiroX][ctrlTabuleiroY].trava;
                fprintf(pont_arq, "%d,", valor);

        }
    }

    for (int ctrlObjetivo = 0; ctrlObjetivo < 7; ctrlObjetivo++) {

            strcpy(palavra, jogo->objetivo[ctrlObjetivo].nome);
            fprintf(pont_arq, "%s,", palavra);

    }
    for (int ctrlObjetivo = 0; ctrlObjetivo < 7; ctrlObjetivo++) {
            (valor= jogo->objetivo[ctrlObjetivo].trava);
            fprintf(pont_arq, "%d,", valor);
    }

    for (int ctrlPontoX = 0; ctrlPontoX < 2; ctrlPontoX++) {
        for (int ctrlPontoY = 0; ctrlPontoY < 3; ctrlPontoY++) {

                strcpy(palavra,jogo->ponto[ctrlPontoX][ctrlPontoY].nome);
                fprintf(pont_arq, "%s,", palavra);

        }
    }
    for (int ctrlPontoX = 0; ctrlPontoX < 2; ctrlPontoX++) {
        for (int ctrlPontoY = 0; ctrlPontoY < 3; ctrlPontoY++) {
                (valor=jogo->ponto[ctrlPontoX][ctrlPontoY].trava);
                fprintf(pont_arq, "%d,", valor);

        }
    }
    for(int ctrlCasas=0;ctrlCasas<6;ctrlCasas++){
        strcpy(palavra,jogo->casas[ctrlCasas].nome);
        fprintf(pont_arq,"%s,",palavra);
    }
    for (int ctrlObjetivoAux = 0; ctrlObjetivoAux < 7; ctrlObjetivoAux++) {
            strcpy(palavra, jogo->objetivoAux[ctrlObjetivoAux].nome);
            fprintf(pont_arq, "%s,", palavra);
    }

    (valor=jogo->dificuldade);
    fprintf(pont_arq, "%d", valor);
    (valor=jogo->estado);
    fprintf(pont_arq, "%d", valor);
    fclose(pont_arq);
}

void leitura(jogo *jogo){
  FILE* fp = fopen("dados.csv", "r");
    if (fp == NULL) {
        printf("Falha ao abrir o arquivo");
    }
    // separa linhas
    char linha[800];
    char *ponteiroControle;
    while (fgets(linha, 800, fp) != NULL) {
        ponteiroControle = strtok(linha, ",");
        while( ponteiroControle != NULL ){
                for(int i=0; i<36;i++){
                        strcpy(jogo->pilha[i].nome,ponteiroControle);
                        ponteiroControle = strtok(NULL,",");
                    }
                for (int ctrlTabuleiroX = 0; ctrlTabuleiroX < 6; ctrlTabuleiroX++) {
                    for (int ctrlTabuleiroY = 0; ctrlTabuleiroY < 6; ctrlTabuleiroY++) {
                        strcpy(jogo->tabuleiro[ctrlTabuleiroX][ctrlTabuleiroY].nome,ponteiroControle);
                        ponteiroControle = strtok(NULL,",");

                    }
                }
                for (int ctrlTabuleiroX = 0; ctrlTabuleiroX < 6; ctrlTabuleiroX++) {
                    for (int ctrlTabuleiroY = 0; ctrlTabuleiroY < 6; ctrlTabuleiroY++) {
                        jogo->tabuleiro[ctrlTabuleiroX][ctrlTabuleiroY].trava=atoi(ponteiroControle);
                        ponteiroControle = strtok(NULL, ",");
                    }
                }
                for (int ctrlObjetivo = 0; ctrlObjetivo < 7; ctrlObjetivo++) {
                    strcpy(jogo->objetivo[ctrlObjetivo].nome, ponteiroControle);
                    ponteiroControle = strtok(NULL, ",");
                }
                for (int ctrlObjetivo = 0; ctrlObjetivo < 7; ctrlObjetivo++) {
                    jogo->objetivo[ctrlObjetivo].trava= atoi(ponteiroControle);
                    ponteiroControle = strtok(NULL, ",");
                }
                for (int ctrlPontoX = 0; ctrlPontoX < 2; ctrlPontoX++) {
                    for (int ctrlPontoY = 0; ctrlPontoY < 3; ctrlPontoY++) {
                        strcpy(jogo->ponto[ctrlPontoX][ctrlPontoY].nome,ponteiroControle);
                        ponteiroControle = strtok(NULL, ",");
                    }
                }
                for (int ctrlPontoX = 0; ctrlPontoX < 2; ctrlPontoX++) {
                    for (int ctrlPontoY = 0; ctrlPontoY < 3; ctrlPontoY++) {
                        jogo->ponto[ctrlPontoX][ctrlPontoY].trava=atoi(ponteiroControle);
                        ponteiroControle = strtok(NULL, ",");
                    }
                }
                for(int ctrlCasa = 0; ctrlCasa< 6; ctrlCasa++) {
                    strcpy(jogo->casas[ctrlCasa].nome, ponteiroControle);
                    ponteiroControle = strtok(NULL, ",");
                }
                for(int ctrlObjetivoAux = 0; ctrlObjetivoAux < 7; ctrlObjetivoAux++) {
                    strcpy(jogo->objetivoAux[ctrlObjetivoAux].nome, ponteiroControle);
                    ponteiroControle = strtok(NULL, ",");
                }
                jogo->dificuldade=atoi(ponteiroControle);
                ponteiroControle = strtok(NULL, ",");

                jogo->estado=atoi(ponteiroControle);
                ponteiroControle = strtok(NULL, ",");
        }
    }
    fclose(fp);
 }
void leituraNovoJogo(jogo *jogo){
  FILE* fp = fopen("dadosBase.csv", "r");
    if (fp == NULL) {
        printf("Falha ao abrir o arquivo");
    }
    // separa linhas
    char linha[800];
    char *ponteiroControle;
    while (fgets(linha, 800, fp) != NULL) {
        ponteiroControle = strtok(linha, ",");
        while( ponteiroControle != NULL ){
                for(int i=0; i<36;i++){
                        strcpy(jogo->pilha[i].nome,ponteiroControle);
                        ponteiroControle = strtok(NULL,",");
                    }
                for (int ctrlTabuleiroX = 0; ctrlTabuleiroX < 6; ctrlTabuleiroX++) {
                    for (int ctrlTabuleiroY = 0; ctrlTabuleiroY < 6; ctrlTabuleiroY++) {
                        strcpy(jogo->tabuleiro[ctrlTabuleiroX][ctrlTabuleiroY].nome,ponteiroControle);
                        ponteiroControle = strtok(NULL,",");

                    }
                }
                for (int ctrlTabuleiroX = 0; ctrlTabuleiroX < 6; ctrlTabuleiroX++) {
                    for (int ctrlTabuleiroY = 0; ctrlTabuleiroY < 6; ctrlTabuleiroY++) {
                        jogo->tabuleiro[ctrlTabuleiroX][ctrlTabuleiroY].trava=atoi(ponteiroControle);
                        ponteiroControle = strtok(NULL, ",");
                    }
                }
                for (int ctrlObjetivo = 0; ctrlObjetivo < 7; ctrlObjetivo++) {
                    strcpy(jogo->objetivo[ctrlObjetivo].nome, ponteiroControle);
                    ponteiroControle = strtok(NULL, ",");
                }
                for (int ctrlObjetivo = 0; ctrlObjetivo < 7; ctrlObjetivo++) {
                    jogo->objetivo[ctrlObjetivo].trava= atoi(ponteiroControle);
                    ponteiroControle = strtok(NULL, ",");
                }
                for (int ctrlPontoX = 0; ctrlPontoX < 2; ctrlPontoX++) {
                    for (int ctrlPontoY = 0; ctrlPontoY < 3; ctrlPontoY++) {
                        strcpy(jogo->ponto[ctrlPontoX][ctrlPontoY].nome,ponteiroControle);
                        ponteiroControle = strtok(NULL, ",");
                    }
                }
                for (int ctrlPontoX = 0; ctrlPontoX < 2; ctrlPontoX++) {
                    for (int ctrlPontoY = 0; ctrlPontoY < 3; ctrlPontoY++) {
                        jogo->ponto[ctrlPontoX][ctrlPontoY].trava=atoi(ponteiroControle);
                        ponteiroControle = strtok(NULL, ",");
                    }
                }
                for(int ctrlCasa = 0; ctrlCasa< 6; ctrlCasa++) {
                    strcpy(jogo->casas[ctrlCasa].nome, ponteiroControle);
                    ponteiroControle = strtok(NULL, ",");
                }
                for(int ctrlObjetivoAux = 0; ctrlObjetivoAux < 7; ctrlObjetivoAux++) {
                    strcpy(jogo->objetivoAux[ctrlObjetivoAux].nome, ponteiroControle);
                    ponteiroControle = strtok(NULL, ",");
                }
                jogo->dificuldade=atoi(ponteiroControle);
                ponteiroControle = strtok(NULL, ",");

                jogo->estado=atoi(ponteiroControle);
                ponteiroControle = strtok(NULL, ",");
        }
    }
    fclose(fp);
 }
