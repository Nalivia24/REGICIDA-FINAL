#include "header.h"

int main() {
  setlocale(LC_ALL, "Portuguese");
  jogo j;
  jogo *jogo;
  jogo = &j;
  int i;
  printf ("__________              .__       .__    .___       \n");
  printf ("\\______   \\ ____   ____ |__| ____ |__| __| _/____   \n");
  printf (" |       _// __ \\ / ___\\|  |/ ___\\|  |/ __ |\\__  \\  \n");
  printf (" |    |   \\  ___// /_/  >  \\  \\___|  / /_/ | / __ \\_\n");
  printf (" |____|_  /\\___  >___  /|__|\\___  >__\\____ |(____  /\n");
  printf ("                /_____/                             \n");
  printf("           ______\n");
  printf("        .-'      '-.\n");
  printf("       /            \\ \n");
  printf("      |              |\n");
  printf("      |,  .-.  .-.  ,|\n");
  printf("      | )(__/  \\__)( |\n");
  printf("      |/     /\     \\| \n");
  printf("      (_     ^^     _)\n");
  printf("       \\__|IIIIII|__/\n");
  printf("        | \\IIIIII/ |\n");
  printf("        \\          /\n");
  printf("         ----------\n");

  printf("1- jogar\n2- carregar jogo\n3- encerrar\n");
  scanf("%d", &i);
  system("cls");
  if (i == 1) {
    novoJogo(jogo);
  } else if (i == 2) {
    leitura(jogo);
    jogar(jogo);

  } else if(i==3){
    return 0;
  }else{
    printf("Op��o inv�lida");
  }
}
