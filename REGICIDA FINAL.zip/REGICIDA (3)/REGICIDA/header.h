#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <time.h>
#include <stdbool.h>

#define CINCO 5
typedef struct{
    char nome[1];
    int trava;
}casa;

typedef struct{
    casa casas[6];// armazena as casa que ser�o usadas no jogo, temos a b c d e f.
    casa tabuleiro[6][6];
    casa pilha[36];
    casa ponto[2][3];
    casa objetivo[7];
    casa objetivoAux[7];
    int estado;
    int dificuldade;
    int coroas;
}jogo;

void printarTabuleiro(jogo *jogo);
void guerra(jogo *jogo);
void printarObjeitivo(jogo *jogo) ;
void intriga(jogo *jogo) ;
void virarLadoAlfa(jogo *jogo, int x, int y);
int buscaTrava(jogo *jogo, int x, int y);
void virarLadoBeta(jogo *jogo, int x, int y);
void preencherPilha(jogo *jogo);
void corvo(jogo *jogo);
void leituraNovoJogo(jogo *jogo);
void leitura(jogo *jogo);
void tabelaPontos(jogo *jogo);
void novoJogo(jogo *jogo);
void revelacao(jogo *jogo) ;
void expansao(jogo *jogo) ;
void verifica(jogo *jogo);
void jogar(jogo *jogo);
int adj(int xA,int yA,int xB,int yB);
void gravacao(jogo *jogo);
